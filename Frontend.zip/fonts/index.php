<?php
header("Location: https://trinityseal.me");
die();
?>