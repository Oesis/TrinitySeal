<?php
header("Location: https://trinityseal.me/download/TrinitySeal.zip");
die();
?>